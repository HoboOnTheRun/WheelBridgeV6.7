$ErrorActionPreference='Stop'
# Steam resolves the installed game location; installation.json is only needed
# by package removal, not to launch an already-installed game.
if(!(Get-Process steam -ErrorAction SilentlyContinue)){throw 'Start Steam before launching the game.'}
Start-Process 'steam://rungameid/2929250'
