@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-OverTheHill.ps1"
pause
