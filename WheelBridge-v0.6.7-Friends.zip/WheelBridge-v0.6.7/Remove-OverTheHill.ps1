$ErrorActionPreference='Stop'
$record=Join-Path $PSScriptRoot 'installation.json'
if(!(Test-Path -LiteralPath $record)){throw 'No installation manifest found.'}
$data=Get-Content -LiteralPath $record -Raw | ConvertFrom-Json
$game=[IO.Path]::GetFullPath($data.GameFolder).TrimEnd('\')
if(!(Test-Path -LiteralPath (Join-Path $game 'over the hill.exe'))){throw 'Recorded game folder is unavailable.'}
if(Get-Process -Name 'over the hill' -ErrorAction SilentlyContinue){throw 'Close the game before removing the mod.'}
foreach($file in $data.Files){
 $target=[IO.Path]::GetFullPath((Join-Path $game $file.Relative))
 if(!$target.StartsWith($game+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Invalid manifest path.'}
 if(Test-Path -LiteralPath $target){if((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -eq $file.Hash){Remove-Item -LiteralPath $target}else{Write-Warning "Changed file retained: $target"}}
}
Move-Item -LiteralPath $record -Destination ($record+'.removed-'+(Get-Date -Format 'yyyyMMddHHmmss'))
Write-Output 'Recorded mod files removed. Generated logs, bindings, and existing loaders were preserved.'
