@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Update-Companion.ps1"
pause
