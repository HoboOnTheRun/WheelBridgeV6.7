# WheelBridge 0.6.7
Created by Hobo 0n The Run.

Use your wheel, pedals and accessories as a virtual Xbox controller. Separate
profiles store calibration and feedback settings for each game.

## Quick start
1. Extract the entire ZIP into a writable folder. Keep its files together.
2. Open **WheelBridge-v0.6.7.exe**. Install the included ViGEmBus driver using
   **Driver installer** if required, then reopen the app.
3. Select your game, choose your devices and calibrate their inputs.
4. Click **Start controller**. Feedback is enabled separately.

## Over the Hill
Close the game and run **Install-OverTheHill.cmd**. The installer includes
MelonLoader 0.7.3 x64, a private .NET runtime and the telemetry companion.
Choose the game's folder if prompted. It preserves existing files and refuses
incompatible loaders. Keep the generated installation.json for safe removal.

Start Steam and the game, select **Over the Hill** in WheelBridge, start the
controller, then **Enable feedback** and return to the game.

- Initial FFB limit: 5%; adjustable to 30%. Increase gradually to suit your wheel.
- Corrected reverse direction is enabled by default for new Over the Hill profiles.
- Bumps now ranges from 0 to 5; try 3 for stronger bumps. Tyre forces and Damping remain 0 to 2. Bumps also controls the brief
  collision shudder; setting Bumps to zero disables both.
- Ctrl + Alt + Backspace disables feedback. Stop controller also stops forces.
- Menus and pause produce zero force. Focus loss or stale data stops a live
  feedback session; re-enable when ready.
- Close the wheel manufacturer's control panel before playing.

Already using the companion? With the game closed, run **Update-Companion.cmd**,
then use this version of WheelBridge. App 0.6.7 and companion 0.6.7 belong together.
The updater uses an existing installation record or the standard Steam location.
If updating a nonstandard installation, keep the prior installation.json in this
folder or pass through your existing package's updater; do not delete the record.

To remove files installed by this package, close the game and run
**Remove-OverTheHill.cmd**. Keep the generated installation record with the package.

## Other games
GTA V and other games use adjustable manual centring. They do not receive
vehicle telemetry through this companion. Settings save on game switch or exit.
Every user must calibrate their own controls; no personal profile is included.

## Compatibility and testing
Windows x64. Over the Hill interfaces checked against game build 25992246.
Force feedback was confirmed by the author on a Thrustmaster T300RS. The new
collision shudder passes software tests but still needs in-game confirmation.
Full host/client co-op, reconnect and host-migration testing remains incomplete.
The companion only reads the local player's vehicle and respects the game's
ModsAllowed setting. Each player needs their own installation and calibration.
Game updates may require a companion update.

The effect approximates steering forces from vehicle physics; it is not measured
steering-rack torque. It does not modify game physics or multiplayer state.

## Troubleshooting
Close other WheelBridge copies if the telemetry port is busy. Driver: Playing
reports software playback, not measured physical wheel force. Check the wheel's
manufacturer force test if nothing is felt. Wheel diagnostics are written to
centring-diagnostics.log; companion diagnostics are in the game's
MelonLoader/Latest.log. Do not upload logs without checking their contents.

## Included components
Keep the DLLs, Dependencies and Companion folders beside the app. They are
required by the app or installer. ViGEmBus 1.22.0 is included for the virtual
controller. Bundled third-party license and notice files are retained.

0.6.7 captures collisions in the game callback before transient data clears.
It observes the callback without suppressing or modifying it. Captured local hits
appear as 'Local collision captured' in MelonLoader/Latest.log. Physical impact
response still needs verification. Collision shudder can use up to the selected
FFB limit at high Bumps settings; the combined output never exceeds that limit.

