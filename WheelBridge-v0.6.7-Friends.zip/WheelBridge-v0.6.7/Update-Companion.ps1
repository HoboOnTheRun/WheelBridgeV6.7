$ErrorActionPreference='Stop'
if(Get-Process -Name 'over the hill' -ErrorAction SilentlyContinue){throw 'Close Over the Hill first, then run this updater again.'}
$record=Join-Path $PSScriptRoot 'installation.json'
$game='C:\Program Files (x86)\Steam\steamapps\common\over the hill'
$data=$null
if(Test-Path -LiteralPath $record){$data=Get-Content -LiteralPath $record -Raw | ConvertFrom-Json;$game=$data.GameFolder}
$target=Join-Path $game 'Mods\WheelBridge.OverTheHill.dll'
$source=Join-Path $PSScriptRoot 'Companion\WheelBridge.OverTheHill.dll'
if(!(Test-Path -LiteralPath $target)){throw 'Existing WheelBridge companion not found. Use Install-OverTheHill.cmd for a new installation.'}
$backup=Join-Path $PSScriptRoot 'Backups'
New-Item -ItemType Directory -Path $backup -Force | Out-Null
Copy-Item -LiteralPath $target -Destination (Join-Path $backup ('WheelBridge.OverTheHill-'+[Guid]::NewGuid().ToString('N')+'.dll.bak'))
Copy-Item -LiteralPath $source -Destination $target -Force
if((Get-FileHash -LiteralPath $target).Hash -ne (Get-FileHash -LiteralPath $source).Hash){throw 'Update verification failed.'}
if($data){foreach($entry in $data.Files){if($entry.Relative -eq 'Mods\WheelBridge.OverTheHill.dll'){$entry.Hash=(Get-FileHash -LiteralPath $target).Hash}};$data | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $record -Encoding UTF8}
Write-Output 'Companion updated to 0.6.7. Use WheelBridge-v0.6.7.exe, then restart the game. Collision shudder stays within your FFB limit.'



