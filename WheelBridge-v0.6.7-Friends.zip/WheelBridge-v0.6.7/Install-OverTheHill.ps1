param([string]$GameFolder='')
$ErrorActionPreference='Stop'
if(!$GameFolder){
 $candidates=@('C:\Program Files (x86)\Steam\steamapps\common\over the hill','D:\SteamLibrary\steamapps\common\over the hill')
 $GameFolder=$candidates | Where-Object {Test-Path -LiteralPath (Join-Path $_ 'over the hill.exe')} | Select-Object -First 1
 if(!$GameFolder){Add-Type -AssemblyName System.Windows.Forms;$picker=New-Object System.Windows.Forms.FolderBrowserDialog;$picker.Description='Choose the folder containing over the hill.exe';if($picker.ShowDialog() -ne 'OK'){throw 'Installation cancelled.'};$GameFolder=$picker.SelectedPath;$picker.Dispose()}
}
$game=[IO.Path]::GetFullPath($GameFolder).TrimEnd('\')
if(!(Test-Path -LiteralPath (Join-Path $game 'over the hill.exe'))){throw 'Select the folder containing over the hill.exe using -GameFolder.'}
if(Get-Process -Name 'over the hill' -ErrorAction SilentlyContinue){throw 'Close Over the Hill before installing.'}
$record=Join-Path $PSScriptRoot 'installation.json'
if(Test-Path -LiteralPath $record){throw 'An installation is already recorded. Remove it with Remove-OverTheHill.ps1 before reinstalling.'}
$files=[Collections.Generic.List[object]]::new()
function Install-One([string]$Source,[string]$Relative){
 $target=[IO.Path]::GetFullPath((Join-Path $game $Relative))
 if(!$target.StartsWith($game+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Invalid installation path.'}
 if(Test-Path -LiteralPath $target){throw "Will not overwrite an existing file: $target"}
 New-Item -ItemType Directory -Path (Split-Path $target) -Force | Out-Null
 Copy-Item -LiteralPath $Source -Destination $target
 $files.Add([pscustomobject]@{Relative=$Relative;Hash=(Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash})
}
try{
 $loader=Join-Path $game 'MelonLoader\net6\MelonLoader.dll'
 if(!(Test-Path -LiteralPath $loader)){
  if(Test-Path -LiteralPath (Join-Path $game 'version.dll')){throw 'An existing loader was found. Set up MelonLoader 0.7.3 x64 separately before using this installer.'}
  $source=Join-Path $PSScriptRoot 'Dependencies\MelonLoader'
  # Generated folders may remain after removal; only file collisions block installation.
  foreach($file in Get-ChildItem -LiteralPath $source -Recurse -File){$relative=$file.FullName.Substring($source.Length+1);if(Test-Path -LiteralPath (Join-Path $game $relative)){throw "Existing loader file needs attention: $relative. No files were changed."}}
  foreach($file in Get-ChildItem -LiteralPath $source -Recurse -File){Install-One $file.FullName $file.FullName.Substring($source.Length+1)}
 }else{
  $version=[Reflection.AssemblyName]::GetAssemblyName($loader).Version
  if($version.Major -ne 0 -or $version.Minor -ne 7 -or $version.Build -ne 3){throw "Expected MelonLoader 0.7.3, found $version. Existing loader preserved."}
 }
 Install-One (Join-Path $PSScriptRoot 'Companion\WheelBridge.OverTheHill.dll') 'Mods\WheelBridge.OverTheHill.dll'
 [pscustomobject]@{GameFolder=$game;Files=$files.ToArray()} | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $record -Encoding UTF8
 Write-Output 'Installed. Start Steam, then use Launch-OverTheHill.cmd. Feedback remains off until enabled in WheelBridge.'
}catch{
 # Roll back only exact files created in this attempt, after checking containment.
 foreach($entry in $files){$target=[IO.Path]::GetFullPath((Join-Path $game $entry.Relative));if($target.StartsWith($game+'\',[StringComparison]::OrdinalIgnoreCase) -and (Test-Path -LiteralPath $target)){if((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -eq $entry.Hash){Remove-Item -LiteralPath $target}}}
 throw
}
